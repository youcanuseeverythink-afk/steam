# Steam Turbine Compressors

تطبيق ويب ثابت (HTML/CSS/JS) بواجهة عربية RTL.

- `index.html` : الهيكل (HTML)
- `style.css` : التنسيق
- `app.js` : منطق التطبيق (تصفح، بحث، مساعد، اختبار، نموذج 3D)
- `data.js` : المحتوى النصي (`const D`) ومسارات الصور
- `assets/` : الشعار والصورة و426 صفحة WebP في `assets/pages/`
- يعتمد على three.js r128 من CDN

التشغيل: خدمه عبر سيرفر محلي (مثل `npx serve` أو `python3 -m http.server`).
