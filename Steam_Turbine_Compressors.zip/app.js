const $=id=>document.getElementById(id);
['lg','lg2','bl'].forEach(i=>$(i).src=D.logo);$('ph').src=D.photo;
let cur=0;const N=D.pages.length;$('tp').textContent=N;$('pn').max=N;
const IMG=i=>D.img[i];
const G=D.gl.trim().split('\n').map(l=>{const a=l.split('|');return{en:a[0],ar:a[1],ch:+a[2]||0}});
const esc=s=>s.replace(/[.*+?^${}()|[\]\\\/]/g,'\\$&');
const RT=G.map((t,i)=>({i,t,re:new RegExp('(^|[^A-Za-z])('+esc(t.en)+'(?:s|es)?)(?![A-Za-z])','gi')})).sort((a,b)=>b.t.en.length-a.t.en.length);
const nar=s=>s.replace(/\s*\(.*\)/,'');
function tr(line){let o=line,hit=new Set(),w=0;RT.forEach(r=>{o=o.replace(r.re,(m,p,x)=>{hit.add(r.i);w+=r.t.en.split(' ').length;return p+'\u0001'+r.i+'\u0002'})});o=o.replace(/\u0001(\d+)\u0002/g,(m,i)=>nar(G[i].ar));const tot=(line.match(/[A-Za-z]{2,}/g)||[]).length;return{ar:o,hit,cov:tot?Math.min(1,w/tot):0}}
const chOf=p=>{let c=0;D.ch.forEach((x,i)=>{if(x.s<=p)c=i});return c};const chEnd=i=>D.ch[i+1]?D.ch[i+1].s:N;
const chIdx=n=>Math.max(0,D.ch.findIndex(c=>c.n==String(n)));
const ct=c=>(D.ch[c].n?'الفصل '+D.ch[c].n+': ':'')+D.ch[c].ta;
function div(c,t){const d=document.createElement('div');if(c)d.className=c;if(t!=null)d.textContent=t;return d}
D.ch.forEach((c,i)=>{const o=document.createElement('option');o.value=i;o.textContent=(c.n?c.n+'. ':'')+c.t;$('chs').appendChild(o)});
const qc=$('qc');qc.innerHTML='<option value="0">كل الفصول</option>';D.ch.forEach(c=>{if(c.n){const o=document.createElement('option');o.value=c.n;o.textContent='الفصل '+c.n+' – '+c.ta;qc.appendChild(o)}});
D.sched.forEach(s=>{$('sch').appendChild(div('', 'اليوم '+s.d+': الفصول '+s.a+(s.b>s.a?'–'+s.b:'')))});
/* lightbox */
let lbi=0;function zoom(i){lbi=i;$('lbi').src=IMG(i);$('lbt').textContent='صفحة '+(i+1);$('lb').hidden=false;$('lbs').scrollTo(0,0)}
$('lbc').onclick=()=>$('lb').hidden=true;
$('lbsh').onclick=async()=>{try{const b=await (await fetch(IMG(lbi))).blob();const f=new File([b],'page-'+(lbi+1)+'.'+(b.type.split('/')[1]||'jpg'),{type:b.type});if(navigator.canShare&&navigator.canShare({files:[f]}))await navigator.share({files:[f],title:'Steam Turbine Compressors – صفحة '+(lbi+1)});else{const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=f.name;a.click()}}catch(e){}};
function pimg(i,cls){const m=document.createElement('img');m.src=IMG(i);m.className=cls||'pgi';m.loading='lazy';m.onclick=()=>zoom(i);return m}
function tab(n){document.querySelectorAll('.tab').forEach((t,i)=>t.classList.toggle('on',i==n));[...$('nv').children].forEach((x,i)=>x.classList.toggle('on',i==n));scrollTo(0,0);if(n==5)init3d()}
$('nv').onclick=e=>{const b=e.target.closest('button');if(b)tab(+b.dataset.t)};document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>tab(+b.dataset.go));
function show(p){cur=Math.max(0,Math.min(N-1,p));$('im').src=IMG(cur);$('im').onclick=()=>zoom(cur);$('pn').value=cur+1;$('o0').innerHTML='';const c=chOf(cur);$('chs').value=c;$('c4').textContent=ct(c);gal(c)}
function open_(p){tab(1);show(p)}
function gal(c){const g=$('gal');g.innerHTML='';for(let i=D.ch[c].s;i<chEnd(c);i++){const m=pimg(i,'');m.onclick=()=>zoom(i);g.appendChild(m)}}
$('nx').onclick=()=>show(cur+1);$('pv').onclick=()=>show(cur-1);$('pn').onchange=e=>show(+e.target.value-1);$('chs').onchange=e=>show(D.ch[e.target.value].s);
const lines=i=>D.pages[i].split('\n').filter(l=>l.trim().length>2);
function trLines(ls,box,withCov){let tot=0,n=0;ls.forEach(l=>{const r=tr(l),d=div('tl');d.appendChild(div('e',l));const a=div('r',r.ar);a.dir='auto';d.appendChild(a);box.appendChild(d);if(/[A-Za-z]{3}/.test(l)){tot+=r.cov;n++}});if(withCov)box.insertAdjacentHTML('afterbegin','<div class="muted">ترجمة مصطلحات الملف (قاموس مدمج). التغطية التقريبية: '+(n?Math.round(tot/n*100):0)+'%</div>')}
$('tr').onclick=()=>{const b=$('o0');b.innerHTML='';const ls=lines(cur);if(!ls.length){b.textContent='لا يوجد نص قابل للقراءة في هذه الصفحة؛ شاهد الصورة.';return}trLines(ls,b,true)};
$('ex').onclick=()=>{const b=$('o0');b.innerHTML='';const c=chOf(cur),hit=new Set();lines(cur).forEach(l=>tr(l).hit.forEach(i=>hit.add(i)));b.appendChild(div('src',ct(c)+' – صفحة '+(cur+1)));
 const first=lines(cur).find(l=>l.length>12);if(first){b.appendChild(div('muted','عنوان/بداية الصفحة في الملف:'));const t=div('',first);t.dir='ltr';b.appendChild(t);const a=div('',tr(first).ar);a.dir='auto';b.appendChild(a)}
 if(hit.size){b.appendChild(div('muted','المصطلحات الواردة في الصفحة:'));b.appendChild(div('',[...hit].slice(0,14).map(i=>G[i].en+' = '+nar(G[i].ar)).join(' • ')))}else b.appendChild(div('muted','الصفحة مخطط/صورة؛ تفاصيلها في الصورة أعلاه.'));
 if(D.ch[c].obj.length){b.appendChild(div('muted','أهداف الفصل من الملف:'));const u=document.createElement('ul');D.ch[c].obj.forEach(o=>{const li=document.createElement('li');li.textContent=tr(o).ar;u.appendChild(li)});b.appendChild(u)}};
function chapSummary(c){const b=div();b.appendChild(div('src',ct(c)+' (صفحة '+(D.ch[c].s+1)+')'));const add=(h,arr)=>{if(!arr.length)return;b.appendChild(div('muted',h));const u=document.createElement('ul');arr.forEach(o=>{const li=document.createElement('li'),e=div('',o);e.dir='ltr';e.style.color='var(--mu)';e.style.fontSize='13px';li.appendChild(div('',tr(o).ar));li.appendChild(e);u.appendChild(li)});b.appendChild(u)};
 add('الأهداف (من الملف):',D.ch[c].obj);add('الخلاصات الأساسية (من الملف):',D.ch[c].take);add('سؤال المراجعة (من الملف):',D.ch[c].lc);
 const heads=[];for(let i=D.ch[c].s;i<chEnd(c);i++){const l=lines(i).find(x=>x.length>14&&/[A-Za-z]{4}/.test(x));if(l&&!heads.includes(l)&&heads.length<14)heads.push(l)}
 if(heads.length){b.appendChild(div('muted','محتويات الفصل (عناوين صفحاته):'));const u=document.createElement('ul');heads.forEach(h=>{const li=document.createElement('li');li.textContent=h;li.dir='ltr';u.appendChild(li)});b.appendChild(u)}
 b.appendChild(pimg(D.ch[c].s));const bt=document.createElement('button');bt.textContent='افتح الفصل في الملف';bt.onclick=()=>open_(D.ch[c].s);b.appendChild(bt);return b}
$('cs').onclick=()=>{const b=$('o0');b.innerHTML='';b.appendChild(chapSummary(chOf(cur)))};
$('q').oninput=e=>{const v=e.target.value.trim().toLowerCase(),el=$('sr');el.innerHTML='';if(v.length<3)return;const box=div('card');let n=0;D.pages.forEach((t,i)=>{const k=t.toLowerCase().indexOf(v);if(k>=0&&n<30){n++;const b=document.createElement('button');b.className='opt';b.style.direction='ltr';b.textContent='p.'+(i+1)+' … '+t.slice(Math.max(0,k-25),k+60).replace(/\n/g,' ');b.onclick=()=>{show(i);el.innerHTML=''};box.appendChild(b)}});box.prepend(div('muted',n+' نتيجة'));el.appendChild(box)};
/* ===== Retrieval bot (file only) ===== */
const nz=s=>s.toLowerCase().replace(/[\u064B-\u0652\u0640]/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه');
const key=s=>nz(nar(s)).replace(/^ال/,'');
const stem=w=>{w=w.toLowerCase();if(w.length>5&&/ies$/.test(w))return w.slice(0,-3)+'y';if(w.length>4&&/s$/.test(w)&&!/ss$/.test(w))return w.slice(0,-1);return w};
const ST=new Set('the and for with that this from are was were have has not can what how why which when where who does did you your about into used use using show tell give explain describe meaning mean there their them they then than also any all one two'.split(' '));
const DOCW=D.pages.map(t=>{const m=new Map();(t.toLowerCase().match(/[a-z]{3,}/g)||[]).forEach(w=>{w=stem(w);m.set(w,(m.get(w)||0)+1)});return m});
const DF=new Map();DOCW.forEach(m=>m.forEach((v,k)=>DF.set(k,(DF.get(k)||0)+1)));
const idf=w=>Math.log(1+(N-(DF.get(w)||0)+.5)/((DF.get(w)||0)+.5));
function parseQ(q){const nq=nz(q),terms=new Set(),phr=[];(q.toLowerCase().match(/[a-z]{3,}/g)||[]).forEach(w=>{if(!ST.has(w))terms.add(stem(w))});
 G.forEach(g=>{const k=key(g.ar);if(k.length>=3&&nq.includes(k)){g.en.toLowerCase().split(/[^a-z]+/).filter(x=>x.length>=2).forEach(w=>terms.add(stem(w)));if(g.en.length>3)phr.push(g.en.toLowerCase())}});
 const m=q.toLowerCase();G.forEach(g=>{if(g.en.includes(' ')&&m.includes(g.en.toLowerCase()))phr.push(g.en.toLowerCase())});return{terms:[...terms],phr:[...new Set(phr)]}}
function search(q,lo,hi){const {terms,phr}=parseQ(q);if(!terms.length)return{terms,phr,res:[]};const res=[];
 for(let i=lo||0;i<(hi||N);i++){let s=0;terms.forEach(w=>{const tf=DOCW[i].get(w)||0;if(tf)s+=idf(w)*(tf*2.2)/(tf+1.2)});if(s>0){const low=D.pages[i].toLowerCase();phr.forEach(p=>{if(low.includes(p))s+=3});res.push({i,s})}}
 return{terms,phr,res:res.sort((a,b)=>b.s-a.s)}}
function hitLines(i,terms,max){const out=[];lines(i).forEach(l=>{const ws=(l.toLowerCase().match(/[a-z]{3,}/g)||[]).map(stem);if(terms.some(t=>ws.includes(t)))out.push(l)});return out.slice(0,max||5).map(l=>l.length>170?l.slice(0,170)+'…':l)}
const log=$('log'),hist=[];let busy=false,lastQ='',smp;
const now=()=>new Date().toLocaleTimeString('ar-IQ',{hour:'2-digit',minute:'2-digit'});
function say(who,node){const m=div('msg '+who),t=div('bt');typeof node==='string'?t.textContent=node:t.appendChild(node);m.appendChild(t);m.appendChild(div('tm',now()));log.appendChild(m);log.scrollTop=log.scrollHeight;return m}
function typing(){const m=div('msg bot');m.innerHTML='<div class="dots"><span></span><span></span><span></span></div>';log.appendChild(m);log.scrollTop=log.scrollHeight;return m}
function srcBox(ps){const d=div('srcl');d.appendChild(div('', 'تم استخراج المعلومات من الملف: '+ps.map(p=>'صفحة '+(p+1)).join('، ')+'.'));const r=div('chips');r.style.cssText='display:flex;flex-wrap:wrap;gap:4px;margin-top:6px;border:0;padding:0';ps.forEach(p=>{const b=document.createElement('button');b.textContent='📄 صفحة '+(p+1);b.onclick=()=>zoom(p);r.appendChild(b)});d.appendChild(r);return d}
function ctxFor(q){let pages=[],extra='';const m=q.match(/(?:فصل|الفصل|chapter|ch)\s*0?(\d{1,2})/i),dm=q.match(/(?:يوم|day)\s*(\d)/i);
 if(m&&+m[1]>=1&&+m[1]<=17){const c=chIdx(m[1]),ch=D.ch[c];extra='Chapter '+ch.n+' ('+ch.t+') Objectives: '+ch.obj.join('; ')+' | Key takeaways: '+ch.take.join('; ')+' | Review questions: '+ch.lc.join('; ');pages=[ch.s];for(let i=ch.s+1;i<chEnd(c)&&pages.length<5;i++)if(D.pages[i].length>150)pages.push(i)}
 else if(dm&&D.sched.find(x=>x.d==dm[1])){const sd=D.sched.find(x=>x.d==dm[1]);extra='Day '+sd.d+' chapters '+sd.a+'-'+sd.b+': '+sd.rows.join(' | ');pages=[1]}
 else{let r=search(q);if(!r.res.length&&lastQ)r=search(lastQ+' '+q);pages=r.res.slice(0,5).map(x=>x.i);ctxFor.t=r.terms}
 return{pages,extra,text:(extra?extra+'\n\n':'')+pages.map(i=>'[Page '+(i+1)+']\n'+D.pages[i].slice(0,1700)).join('\n\n')}}
const SYS='أنت المساعد الفني الرسمي لتطبيق Steam Turbine Compressors التابع للهيئة العامة للمهندسين الكيميائيين في البصرة (مؤسس التطبيق: م. علي سيف). تخاطب المستخدم بأسلوب مراسلة رسمي ومهذب جداً وبلغة عربية فصحى، وتشرح بتفصيل هندسي مرتب ومتسلسل مستنداً حصراً إلى مقتطفات ملف الدورة (Steam Turbine Design, Maintenance and Failure Diagnostics) المرفقة أدناه، دون إضافة معلومات من خارجها. اذكر المصطلح التقني بالإنجليزية بين قوسين بعد ترجمته. لا تستخدم Markdown أو النجوم أو الرموز التعبيرية؛ استخدم فقرات قصيرة أو ترقيماً بسيطاً. لا تذكر أرقام الصفحات داخل الشرح. إذا لم تتضمن المقتطفات جواباً فاكتب في السطر الأول NOFILE ثم اعتذر رسمياً باختصار واقترح إعادة صياغة السؤال. إذا كانت الرسالة تحية أو شكراً فأجب بلطف رسمي. في آخر سطر مستقل اكتب PAGES: متبوعة بأرقام الصفحات التي استخدمتها فعلاً مفصولة بفواصل، أو PAGES: none عند عدم استخدام الملف.';
const clean=t=>t.replace(/\*\*/g,'').replace(/^#+\s*/gm,'').replace(/\n?\s*PAGES:.*$/is,'').replace(/^NOFILE\s*/,'').trim();
function offline(q,c){const hl=c.pages.slice(0,2);if(!c.pages.length)return{t:'تحية طيبة،\nنأسف لإبلاغكم بأنه لم يُعثر في الملف على ما يطابق استفساركم. يُرجى إعادة صياغة السؤال باستخدام مصطلح فني من الملف (مثل balance piston أو turning gear) أو ذكر رقم الفصل.',p:[]};
 const d=div();d.appendChild(div('', 'تحية طيبة،\nنفيدكم بأن الملف يتضمن المعلومات ذات الصلة التالية:'));hl.forEach(i=>{const ls=hitLines(i,ctxFor.t||[],4);trLines(ls.length?ls:lines(i).slice(0,3),d,false)});return{n:d,p:hl}}
async function reply(q){const c=ctxFor(q),ty=typing();let out='',ps=c.pages,ok=false;
 try{smp=smp||await claude.use('sample');
  if(smp){const h=hist.slice(-6).map(x=>x[0]+': '+x[1]).join('\n');const bub=say('bot','');bub.style.display='none';
   const r=await smp(SYS+'\n\n=== المحادثة السابقة ===\n'+(h||'لا يوجد')+'\n\n=== مقتطفات الملف ===\n'+(c.text||'(لا توجد مقتطفات مطابقة)')+'\n\n=== رسالة المستخدم ===\n'+q,{cache:false,modelTier:'default',onText:({text})=>{const t=clean(text);if(t){ty.remove();bub.style.display='';bub.firstChild.textContent=t;log.scrollTop=log.scrollHeight}}});
   const raw=r.text||'',pm=raw.match(/PAGES:\s*([^\n]*)$/im),nf=/^\s*NOFILE/.test(raw);out=clean(raw);
   let used=pm&&/\d/.test(pm[1])?pm[1].match(/\d+/g).map(x=>+x-1).filter(x=>c.pages.includes(x)):(pm?[]:c.pages.slice(0,3));if(nf)used=[];
   bub.firstChild.textContent=out;if(used.length)bub.insertBefore(srcBox(used),bub.querySelector('.tm'));ty.remove();bub.style.display='';ok=true;hist.push(['المستخدم',q],['المساعد',out.slice(0,600)]);log.scrollTop=log.scrollHeight}}
 catch(e){console.warn(e)}
 if(!ok){ty.remove();const o=offline(q,c),b=say('bot',o.n||o.t);if(o.p.length)b.insertBefore(srcBox(o.p),b.querySelector('.tm'))}
 lastQ=q}
async function ask(q){q=q.trim();if(!q||busy)return;busy=true;say('me',q);await reply(q);busy=false}
$('go').onclick=()=>{const v=$('qi').value;$('qi').value='';ask(v)};$('qi').onkeydown=e=>{if(e.key==='Enter')$('go').click()};
['ما هو الـ balance piston وما وظيفته؟','اشرح نظام الـ gland steam','ما وظيفة turning gear؟','لخّص الفصل 6','ما برنامج اليوم الثالث؟','ما أسباب أعطال التوربين البخاري؟'].forEach(t=>{const b=document.createElement('button');b.textContent=t;b.onclick=()=>ask(t);$('sg').appendChild(b)});
setTimeout(()=>{const t=typing();setTimeout(()=>{t.remove();say('bot','السلام عليكم ورحمة الله وبركاته،\nأهلاً وسهلاً بكم في تطبيق Steam Turbine Compressors التابع للهيئة العامة للمهندسين الكيميائيين في البصرة.\nأنا المساعد الفني الرسمي، ويسرّني الإجابة عن استفساراتكم وشرحها بالتفصيل استناداً إلى ملف دورة التوربين البخاري حصراً، مع بيان الصفحات التي استُخرجت منها المعلومات في ختام كل إجابة.\nتفضّلوا بكتابة سؤالكم أو اختيار أحد المقترحات أدناه.')},900)},300);
/* ===== Quiz from file ===== */
const sh=a=>[...a].sort(()=>Math.random()-.5);
const chTitle=n=>'الفصل '+n+' – '+D.ch[chIdx(n)].ta;
const goodPages=[];for(let i=0;i<N;i++)if(D.ch[chOf(i)].n&&D.pages[i].length>60&&i!==D.ch[chOf(i)].s)goodPages.push(i);
function findLine(t){for(let i=0;i<N;i++)if(D.pages[i].includes(t.slice(0,30)))return i;return D.ch[0].s}
function chOpts(n){const o=sh([...new Set([n,...sh([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]).slice(0,5)])]);if(!o.includes(n))o[0]=n;const f=sh(o).slice(0,4);if(!f.includes(n))f[0]=n;return sh(f).map(x=>chTitle(x))}
function makeQ(n,c){const out=[],cs=D.ch.filter(x=>x.n&&(!c||x.n==c));const pool=[];
 cs.forEach(ch=>{ch.obj.forEach(o=>pool.push({k:'obj',t:o,n:+ch.n}));ch.take.forEach(o=>pool.push({k:'take',t:o,n:+ch.n}))});
 sh(goodPages.filter(i=>!c||D.ch[chOf(i)].n==c)).slice(0,Math.ceil(n/3)).forEach(i=>pool.push({k:'img',i,n:+D.ch[chOf(i)].n}));
 G.filter(g=>g.ch&&(!c||g.ch==c)).forEach(g=>pool.push({k:'term',g,n:g.ch}));
 sh(pool).slice(0,n).forEach(p=>{let o;
  if(p.k==='img'){o=chOpts(p.n);out.push({q:'الصفحة المعروضة (من الملف) تنتمي إلى أي فصل؟',img:p.i,o,a:o.indexOf(chTitle(p.n)),w:'الفصل '+p.n+' – صفحة '+(p.i+1),pg:p.i})}
  else if(p.k==='term'){const g=p.g;if(Math.random()<.5){const op=sh([g,...sh(G.filter(x=>x!==g)).slice(0,3)]).map(x=>nar(x.ar));out.push({q:'ما معنى المصطلح «'+g.en+'» (كما يرد في الملف)؟',o:op,a:op.indexOf(nar(g.ar)),w:g.en+' = '+nar(g.ar)+' — الفصل '+g.ch,pg:D.ch[chIdx(g.ch)].s})}
   else{const op=sh([g,...sh(G.filter(x=>x!==g)).slice(0,3)]).map(x=>x.en);out.push({q:'ما المصطلح الإنجليزي للمعنى «'+nar(g.ar)+'»؟',o:op,a:op.indexOf(g.en),w:g.en+' = '+nar(g.ar)+' — الفصل '+g.ch,pg:D.ch[chIdx(g.ch)].s})}}
  else{o=chOpts(p.n);const pg=findLine(p.t);out.push({q:(p.k==='obj'?'هذا الهدف ورد في أي فصل؟':'هذه الخلاصة وردت في أي فصل؟')+'\n«'+tr(p.t).ar+'»\n('+p.t+')',o,a:o.indexOf(chTitle(p.n)),w:'المصدر: الفصل '+p.n+' – صفحة '+(pg+1),pg:D.ch[chIdx(p.n)].s})}});
 return out}
$('gq').onclick=()=>{const o=$('o3'),qs=makeQ(+$('nq').value,+qc.value);if(!qs.length){o.textContent='لا توجد أسئلة كافية لهذا الاختيار.';return}let i=0,sc=0;
 const draw=()=>{o.innerHTML='';if(i>=qs.length){o.innerHTML='<h3>النتيجة: '+sc+' / '+qs.length+'</h3><p class="muted">'+(sc/qs.length>=.7?'ممتاز! 🎉':'راجع الفصول وأعد المحاولة.')+'</p>';return}
 const q=qs[i],h=div();h.appendChild(div('muted','سؤال '+(i+1)+' من '+qs.length));const t=div('',q.q);t.style.fontWeight='700';t.style.whiteSpace='pre-wrap';h.appendChild(t);if(q.img!=null)h.appendChild(pimg(q.img));let done=false;
 q.o.forEach((x,k)=>{const b=document.createElement('button');b.className='opt';b.textContent=x;b.onclick=()=>{if(done)return;done=true;if(k===q.a)sc++;b.classList.add(k===q.a?'ok':'bad');[...h.querySelectorAll('.opt')][q.a].classList.add('ok');h.appendChild(div('src',(k===q.a?'✔ إجابة صحيحة. ':'✘ الإجابة الصحيحة موضحة. ')+q.w));if(q.img==null&&q.pg!=null)h.appendChild(pimg(q.pg));const nb=document.createElement('button');nb.className='p';nb.textContent=i+1<qs.length?'التالي':'النتيجة';nb.onclick=()=>{i++;draw()};h.appendChild(nb)};h.appendChild(b)});o.appendChild(h)};draw()};
$('lcb').onclick=()=>{const o=$('o3b');o.innerHTML='';const n=+qc.value,cs=D.ch.filter(x=>x.n&&(!n||x.n==n));cs.forEach(ch=>ch.lc.forEach(q=>{const d=div('tl');d.appendChild(div('src',ct(D.ch.indexOf(ch))));d.appendChild(div('',tr(q).ar));const e=div('e',q);e.dir='ltr';e.className='muted';d.appendChild(e);const pg=findLine(q);d.appendChild(pimg(pg));o.appendChild(d)}))};
show(0);
/* ===== 3D: built from the file's HI-turbine / LP-turbine drawings ===== */
const PT={
outer:{en:'Outer casing',kw:/outer casing/i,ch:3},inner:{en:'Inner casing',kw:/inner casing/i,ch:3},rotor:{en:'Turbine rotor',kw:/turbine rotor|rotor/i,ch:3},
blad:{en:'Blading (HP / IP)',kw:/blad/i,ch:4},balance:{en:'Balance piston',kw:/balanc(e|ing) piston/i,ch:3},
hpadm:{en:'HP admission',kw:/HP[- ]admission/i,ch:3},ipadm:{en:'IP admission',kw:/IP[- ]admission/i,ch:3},hpexh:{en:'HP exhaust',kw:/HP[- ]exhaust/i,ch:3},ipexh:{en:'IP exhaust',kw:/IP[- ]exhaust/i,ch:3},
seal:{en:'Shaft sealing',kw:/shaft seal|seal steam|gland/i,ch:5},bearing:{en:'Combined journal and thrust bearing',kw:/thrust bearing|journal bearing/i,ch:7},
turning:{en:'Turning device',kw:/turning (device|gear)/i,ch:8},pedestal:{en:'Bearing pedestal',kw:/pedestal/i,ch:3},foundation:{en:'Foundation',kw:/foundation/i,ch:3},
pushrod:{en:'Push rod connection',kw:/push rod/i,ch:3},cross:{en:'Cross over pipe',kw:/cross ?over/i,ch:6},
lpouter:{en:'LP outer casing',kw:/outer casing/i,ch:6},lpinner:{en:'LP inner casing',kw:/inner casing/i,ch:6},lpblade:{en:'LP drum blades',kw:/drum blade|blad/i,ch:6},
diffuser:{en:'Diffuser / exhaust',kw:/diffuser|exhaust/i,ch:6},condenser:{en:'Condenser',kw:/condenser/i,ch:6},coupling:{en:'Coupling',kw:/coupling/i,ch:9},
generator:{en:'Generator',kw:/generator/i,ch:9},valves:{en:'Main stop and control valves',kw:/stop valve|control valve/i,ch:10}};
let T=null,sel=null;
function select(id){sel=id;const p=PT[id],box=$('pi');box.className='';box.innerHTML='';const h=div('',p.en);h.style.fontWeight='700';h.dir='ltr';box.appendChild(h);const a=div('',tr(p.en).ar);box.appendChild(a);
 const c=chIdx(p.ch),lo=D.ch[c].s,hi=chEnd(c),sc=[];for(let i=lo;i<hi;i++){const n=(D.pages[i].match(new RegExp(p.kw.source,'gi'))||[]).length;if(n)sc.push({i,n})}
 sc.sort((x,y)=>y.n-x.n);const top=sc.slice(0,4);box.appendChild(div('src','📍 '+ct(c)));
 if(!top.length)box.appendChild(div('muted','لا توجد صفحة نصية بهذا الاسم في الفصل؛ افتح الفصل لمشاهدة مخططاته.'));
 top.forEach(x=>{const w=div('tl');w.appendChild(div('src','صفحة '+(x.i+1)));const ls=lines(x.i).filter(l=>p.kw.test(l)).slice(0,3);if(ls.length)trLines(ls,w,false);w.appendChild(pimg(x.i));box.appendChild(w)});
 const b=document.createElement('button');b.className='p';b.textContent='افتح '+ct(c);b.onclick=()=>open_(D.ch[c].s);box.appendChild(b);if(T)T.hl(id)}
function init3d(){if(T)return;if(!window.THREE){$('pi').textContent='تعذّر تحميل مكتبة 3D.';return}
 const cv=$('cv'),R=new THREE.WebGLRenderer({canvas:cv,antialias:true,alpha:true});R.setPixelRatio(Math.min(devicePixelRatio,2));R.outputEncoding=THREE.sRGBEncoding;R.toneMapping=THREE.ACESFilmicToneMapping;R.toneMappingExposure=1.05;R.shadowMap.enabled=true;R.shadowMap.type=THREE.PCFSoftShadowMap;
 const sc=new THREE.Scene(),cam=new THREE.PerspectiveCamera(40,1,.1,300);sc.add(new THREE.HemisphereLight(0xdfe9f5,0x20262c,.5));const dl=new THREE.DirectionalLight(0xffffff,1.1);dl.position.set(8,16,10);dl.castShadow=true;dl.shadow.mapSize.set(2048,2048);Object.assign(dl.shadow.camera,{left:-17,right:17,top:17,bottom:-17,near:1,far:60});dl.shadow.bias=-.0004;sc.add(dl);
 const ec=document.createElement('canvas');ec.width=512;ec.height=256;const eg=ec.getContext('2d'),gr=eg.createLinearGradient(0,0,0,256);gr.addColorStop(0,'#cfd9e4');gr.addColorStop(.5,'#8190a0');gr.addColorStop(.52,'#2b343d');gr.addColorStop(1,'#12161a');eg.fillStyle=gr;eg.fillRect(0,0,512,256);eg.fillStyle='#fff';[[40,40,90,30],[200,28,130,26],[380,48,80,34],[470,90,40,18]].forEach(r=>eg.fillRect(...r));
 const et=new THREE.CanvasTexture(ec);et.mapping=THREE.EquirectangularReflectionMapping;et.encoding=THREE.sRGBEncoding;sc.environment=new THREE.PMREMGenerator(R).fromEquirectangular(et).texture;
 const bc=document.createElement('canvas');bc.width=bc.height=256;const bg=bc.getContext('2d');bg.fillStyle='#999';bg.fillRect(0,0,256,256);for(let k=0;k<1500;k++){const v=120+Math.random()*100|0;bg.fillStyle='rgb('+v+','+v+','+v+')';bg.fillRect(Math.random()*256,Math.random()*256,20+Math.random()*90,1)}
 const BR=new THREE.CanvasTexture(bc);BR.wrapS=BR.wrapT=THREE.RepeatWrapping;BR.repeat.set(2,2);
 const bladeGeo=len=>{const sh=new THREE.Shape();sh.moveTo(-.07,0);sh.quadraticCurveTo(-.02,.06,.07,.012);sh.quadraticCurveTo(0,-.012,-.07,0);const g=new THREE.ExtrudeGeometry(sh,{depth:len,bevelEnabled:false});g.rotateX(-Math.PI/2);g.translate(0,-len/2,0);return g};
 const root=new THREE.Group();root.position.x=-1.5;sc.add(root);const spin=new THREE.Group(),top=new THREE.Group();root.add(spin,top);
 const P={},all=[],TP=Math.PI*2;
 const mt=(id,c,o)=>{P[id]=P[id]||{t:[]};const m=new THREE.MeshPhysicalMaterial(Object.assign({color:c,metalness:.7,roughness:.55,roughnessMap:BR,bumpMap:BR,bumpScale:.5,envMapIntensity:1.1},o||{}));P[id].t.push(m);return m};
 const reg=(id,mesh,par)=>{mesh.userData.part=id;mesh.castShadow=true;mesh.receiveShadow=true;all.push(mesh);(par||root).add(mesh);return mesh};
 const cx=(r,len,s)=>{const g=new THREE.CylinderGeometry(r,r,len,s||32);g.rotateZ(Math.PI/2);return g};const bx=(w,h,d)=>new THREE.BoxGeometry(w,h,d);
 const cy=(r,len,s)=>new THREE.CylinderGeometry(r,r,len,s||20);
 const mk=(id,g,m,x,y,z,par)=>{const o=new THREE.Mesh(g,m);o.position.set(x,y,z||0);return reg(id,o,par)};
 const tr_=.3,gl=(o)=>({transparent:true,opacity:o,side:THREE.DoubleSide});
 const mR=mt('rotor',0xaab4bd,{metalness:1,roughness:.3}),mBl=mt('blad',0xcfd3d8,{metalness:1,roughness:.25}),mLb=mt('lpblade',0xe6eaee,{metalness:1,roughness:.22}),mBp=mt('balance',0xb9803a,{metalness:1,roughness:.32});
 /* rotor train */
 mk('rotor',cx(.25,21),mR,1.2,0,0,spin);mk('rotor',cx(.6,6.2),mR,-3.4,0,0,spin);[-7.5,.6,7.0].forEach(x=>mk('rotor',cx(.3,.9),mR,x,0,0,spin));
 /* HI turbine: x -6.4 .. -0.4  (HP part left, IP part right, per file p.22-26) */
 const row=(id,m,x,r0,len,n,tilt)=>{const im=new THREE.InstancedMesh(bladeGeo(len),m,n),o=new THREE.Object3D();for(let b=0;b<n;b++){const a=b/n*TP;o.position.set(x,Math.cos(a)*(r0+len/2),Math.sin(a)*(r0+len/2));o.rotation.set(-a,tilt,0);o.updateMatrix();im.setMatrixAt(b,o.matrix)}reg(id,im,spin);mk('rotor',cx(r0,.1),mR,x,0,0,spin)};
 for(let s=0;s<7;s++)row('blad',mBl,-5.7+s*.32,.55,.2+s*.025,34,.3);
 for(let s=0;s<8;s++)row('blad',mBl,-3.0+s*.32,.6,.25+s*.03,34,-.3);
 mk('balance',cx(.85,.18),mBp,-6.2,0,0,spin);mk('balance',cx(.85,.18),mBp,-0.7,0,0,spin);
 const hp=(len,r,x,th,m,par,id)=>{const g=new THREE.CylinderGeometry(r,r,len,44,1,true,th,Math.PI);g.rotateZ(Math.PI/2);mk(id,g,m,x,0,0,par)};
 const mO=mt('outer',0x4f6a80,{metalness:.55,roughness:.42,clearcoat:.6,clearcoatRoughness:.25,side:THREE.DoubleSide}),mI=mt('inner',0x8f9aa5,{metalness:.8,roughness:.4,side:THREE.DoubleSide});
 hp(6.0,1.55,-3.4,0,mO,top,'outer');hp(6.0,1.55,-3.4,Math.PI,mO,root,'outer');hp(4.8,1.05,-3.4,0,mI,top,'inner');hp(4.8,1.05,-3.4,Math.PI,mI,root,'inner');
 const rib=(id,m,x,r,half,par)=>{const g=new THREE.TorusGeometry(r,.07,10,48,Math.PI).rotateY(Math.PI/2);if(half)g.rotateX(Math.PI);mk(id,g,m,x,0,0,par)};
 const flange=(id,x,len,r)=>{const m=mt(id,0x56697a,{metalness:.7,roughness:.45}),mb=mt(id,0xb8bcc2,{metalness:1,roughness:.3}),n=Math.floor(len/.45);[-1,1].forEach(sd=>{mk(id,bx(len,.1,.42),m,x,-.05,sd*(r+.1),root);mk(id,bx(len,.1,.42),m,x,.05,sd*(r+.1),top);const hd=new THREE.InstancedMesh(cy(.07,.12,6),mb,n),st=new THREE.InstancedMesh(cy(.05,.34,8),mb,n),o=new THREE.Object3D();for(let k=0;k<n;k++){o.position.set(x-len/2+.3+k*(len-.6)/(n-1),.16,sd*(r+.1));o.updateMatrix();hd.setMatrixAt(k,o.matrix);o.position.y=.12;o.updateMatrix();st.setMatrixAt(k,o.matrix)}reg(id,hd,top);reg(id,st,root)})};
 [-6,-5,-4,-3,-2,-1].forEach(x=>{rib('outer',mO,x,1.55,false,top);rib('outer',mO,x,1.55,true,root)});flange('outer',-3.4,6.0,1.55);
 const mA=mt('hpadm',0xc0392b),mA2=mt('ipadm',0xe67e22),mX=mt('hpexh',0x2980b9),mX2=mt('ipexh',0x8e44ad);
 mk('hpadm',cy(.28,1.7),mA,-4.5,-1.9,0);mk('hpadm',cy(.4,.3),mA,-4.5,-1.1,0);
 mk('ipadm',cy(.28,1.7),mA2,-2.7,-1.9,0);mk('ipadm',cy(.4,.3),mA2,-2.7,-1.1,0);
 mk('hpexh',cy(.3,1.6),mX,-5.8,-1.9,0);mk('hpexh',cy(.42,.3),mX,-5.8,-1.1,0);
 mk('ipexh',cy(.42,.3),mX2,-1.4,1.55,0,top);mk('ipexh',cy(.34,1.5),mX2,-1.4,2.2,0,top);
 /* cross over pipe: IP exhaust (top of HI) -> LP centre */
 const mCr=mt('cross',0xa93226);mk('cross',cy(.34,5.0),mCr,-1.4,2.95+.7,0,top).scale.set(.01,.01,.01);top.children.pop();all.pop();
 mk('cross',cx(.34,5.6),mCr,1.4,3.0,0,top);mk('cross',cy(.34,1.6),mCr,4.2,2.2,0,top);mk('cross',cy(.34,.9),mCr,-1.4,2.95,0,top);
 const mS=mt('seal',0xe07a2f);[-6.5,-0.35,1.95,6.35].forEach(x=>{mk('seal',cx(.62,.3),mS,x,0,0);[-.1,0,.1].forEach(d=>{const t=new THREE.Mesh(new THREE.TorusGeometry(.64,.025,8,40).rotateY(Math.PI/2),mS);t.position.x=x+d;reg('seal',t)})});
 /* pedestals, bearing, turning device, foundation */
 const mF=mt('foundation',0x9b9b9b),mPd=mt('pedestal',0x7b6a58),mBr=mt('bearing',0xa0522d),mTg=mt('turning',0xd4a017);
 mk('foundation',bx(23,.6,4),mF,1.8,-3.6,0);
 [[-7.5,2.2],[0.6,1.8],[7.0,1.8]].forEach(([x,w])=>mk('pedestal',bx(1.7,2.4,2.4),mPd,x,-2.0,0));
 mk('bearing',cx(.5,.8),mBr,-7.5,0,0);mk('bearing',cx(.7,.12),mBr,-8.0,0,0,spin);mk('bearing',cx(.5,.7),mBr,.6,0,0);mk('bearing',cx(.5,.7),mBr,7.0,0,0);
 mk('turning',cx(.75,.22),mTg,-9.0,0,0,spin);for(let i=0;i<24;i++){const a=i/24*TP;const t=new THREE.Mesh(bx(.22,.16,.14),mTg);t.position.set(-9.0,Math.cos(a)*.8,Math.sin(a)*.8);t.rotation.x=-a;reg('turning',t,spin)}mk('turning',bx(.8,.5,.7),mTg,-9.0,-1.2,0);
 mk('pushrod',cx(.07,2.0,10),mt('pushrod',0x333333),0.55,-.2,1.75);mk('pushrod',cx(.07,2.0,10),P.pushrod.t[0],0.55,-.2,-1.75);
 /* LP turbine (double flow, centre x=4.2, file ch.6 p.84-118) */
 const LX=4.2;[-1,1].forEach(sd=>[.5,.95,1.4,1.85].forEach((off,k)=>row('lpblade',mLb,LX+sd*off,.75,.45+k*.2,38,sd*.4)));
 const mLo=mt('lpouter',0x4f6a80,{metalness:.55,roughness:.42,clearcoat:.6,clearcoatRoughness:.25,side:THREE.DoubleSide}),mLi=mt('lpinner',0x8f9aa5,{metalness:.8,roughness:.4,side:THREE.DoubleSide});mk('rotor',cx(.72,4.2),mR,LX,0,0,spin);[2.2,3,3.8,4.6,5.4,6.2].forEach(x=>{rib('lpouter',mLo,x,2.1,false,top);rib('lpouter',mLo,x,2.1,true,root)});flange('lpouter',LX,4.8,2.1);
 hp(4.8,2.1,LX,0,mLo,top,'lpouter');hp(4.8,2.1,LX,Math.PI,mLo,root,'lpouter');hp(4.0,1.45,LX,0,mLi,top,'lpinner');hp(4.0,1.45,LX,Math.PI,mLi,root,'lpinner');
 const mDf=mt('diffuser',0x2f6f73,{metalness:.5,roughness:.5});mk('diffuser',bx(4.6,1.2,2.8),mDf,LX,-2.4,0);
 const mCn=mt('condenser',0x2b6cb0,gl(.5));mk('condenser',bx(5.4,1.8,3.2),mCn,LX,-4.35,0);for(let i=0;i<4;i++)for(let j=0;j<5;j++)mk('condenser',cx(.06,5,8),mt('condenser',0xd0d8e0),LX,-3.9-i*.3,-1+j*.5);
 /* coupling + generator (ch.9: LP-generator coupling) */
 const mK=mt('coupling',0x8899aa);[7.9,8.25].forEach(x=>mk('coupling',cx(.85,.18),mK,x,0,0,spin));for(let i=0;i<10;i++){const a=i/10*TP;mk('coupling',cx(.05,.5,8),mt('coupling',0xffd27f),8.07,Math.cos(a)*.65,Math.sin(a)*.65,spin)}
 const mG=mt('generator',0x1d4f7a,{metalness:.55,roughness:.4,clearcoat:.8});mk('generator',cx(1.15,3.4,48),mG,10.1,0,0);mk('generator',bx(2.6,.7,1.6),mG,10.1,1.3,0);[-1.2,0,1.2].forEach(d=>mk('generator',cx(1.2,.12,48),mt('generator',0x9aa7b2,{metalness:1,roughness:.3}),10.1+d,0,0));
 /* valves (ch.10) */
 const mV=mt('valves',0x2a3b4a);mk('valves',cy(.4,1.0),mV,-4.5,-2.8,2.4);mk('valves',cy(.3,.8),mV,-2.7,-2.8,2.4);mk('valves',bx(.5,.4,.5),mt('valves',0xc0392b),-4.5,-2.0,2.4);mk('valves',bx(.5,.4,.5),P.valves.t[1],-2.7,-2.1,2.4);mk('valves',cx(.14,1.8,12),mV,-3.6,-2.8,2.4);
 /* camera */
 let yaw=.5,pit=.3,dist=24,drag=false,px=0,py=0,mv=0;
 const rs=()=>{const w=cv.clientWidth,h=cv.clientHeight;R.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix()};rs();addEventListener('resize',rs);
 cv.onpointerdown=e=>{drag=true;px=e.clientX;py=e.clientY;mv=0;cv.setPointerCapture(e.pointerId)};
 cv.onpointermove=e=>{if(!drag)return;const dx=e.clientX-px,dy=e.clientY-py;mv+=Math.abs(dx)+Math.abs(dy);yaw-=dx*.008;pit=Math.max(-.2,Math.min(1.3,pit+dy*.006));px=e.clientX;py=e.clientY};
 const rc=new THREE.Raycaster(),v2=new THREE.Vector2();
 cv.onpointerup=e=>{drag=false;if(mv<8){const r=cv.getBoundingClientRect();v2.set((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height*2-1));rc.setFromCamera(v2,cam);const h=rc.intersectObjects(all,false)[0];if(h)select(h.object.userData.part)}};
 cv.onwheel=e=>{e.preventDefault();dist=Math.max(8,Math.min(40,dist+e.deltaY*.02))};$('zi').onclick=()=>dist=Math.max(8,dist-3);$('zo').onclick=()=>dist=Math.min(40,dist+3);
 $('ex3').oninput=e=>{top.position.y=e.target.value/100*3.5};
 cv.onpointermove=(f=>e=>{f(e);if(drag)return;const r=cv.getBoundingClientRect();v2.set((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height*2-1));rc.setFromCamera(v2,cam);const h=rc.intersectObjects(all,false)[0],l=$('lbl');if(h){l.textContent=PT[h.object.userData.part].en;l.style.display='block';l.style.left=(e.clientX-r.left+10)+'px';l.style.top=(e.clientY-r.top+10)+'px'}else l.style.display='none'})(cv.onpointermove);
 $('ex3').value=65;top.position.y=2.3;T={hl(id){for(const k in P)P[k].t.forEach(m=>{if(m.emissive)m.emissive.setHex(k===id?0x2a6a99:0)})}};
 Object.keys(PT).forEach(k=>{const b=document.createElement('button');b.textContent=PT[k].en;b.onclick=()=>select(k);$('parts').appendChild(b)});
 (function loop(){requestAnimationFrame(loop);if($('sp').checked)spin.rotation.x+=.03;if(!drag&&!sel)yaw+=.002;cam.position.set(Math.sin(yaw)*Math.cos(pit)*dist,Math.sin(pit)*dist-1,Math.cos(yaw)*Math.cos(pit)*dist);cam.lookAt(0,-.5,0);R.render(sc,cam)})()}
